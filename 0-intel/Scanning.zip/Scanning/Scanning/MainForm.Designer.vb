﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SubMenu3 = New Scanning.SubMenu()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.SubMenu2 = New Scanning.SubMenu()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.SubMenu1 = New Scanning.SubMenu()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TopMenu = New Scanning.TopMenu()
        Me.SubMenu3.SuspendLayout()
        Me.SubMenu2.SuspendLayout()
        Me.SubMenu1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(31, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(370, 20)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Press the space bar to select the highlighted option"
        '
        'SubMenu3
        '
        Me.SubMenu3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SubMenu3.Controls.Add(Me.Button12)
        Me.SubMenu3.Controls.Add(Me.Button11)
        Me.SubMenu3.Controls.Add(Me.Button10)
        Me.SubMenu3.Controls.Add(Me.Button9)
        Me.SubMenu3.Controls.Add(Me.Button8)
        Me.SubMenu3.Location = New System.Drawing.Point(31, 350)
        Me.SubMenu3.Name = "SubMenu3"
        Me.SubMenu3.Size = New System.Drawing.Size(540, 108)
        Me.SubMenu3.TabIndex = 6
        '
        'Button12
        '
        Me.Button12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.Location = New System.Drawing.Point(415, 19)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(88, 64)
        Me.Button12.TabIndex = 4
        Me.Button12.Text = "Button12"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(317, 19)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(86, 63)
        Me.Button11.TabIndex = 3
        Me.Button11.Text = "Button11"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(223, 19)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(83, 63)
        Me.Button10.TabIndex = 2
        Me.Button10.Text = "Button10"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(126, 19)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(81, 64)
        Me.Button9.TabIndex = 1
        Me.Button9.Text = "Button9"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(32, 19)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(79, 64)
        Me.Button8.TabIndex = 0
        Me.Button8.Text = "Button8"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'SubMenu2
        '
        Me.SubMenu2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SubMenu2.Controls.Add(Me.Button7)
        Me.SubMenu2.Controls.Add(Me.Button6)
        Me.SubMenu2.Controls.Add(Me.Button5)
        Me.SubMenu2.Location = New System.Drawing.Point(31, 213)
        Me.SubMenu2.Name = "SubMenu2"
        Me.SubMenu2.Size = New System.Drawing.Size(347, 112)
        Me.SubMenu2.TabIndex = 5
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(223, 25)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(84, 63)
        Me.Button7.TabIndex = 2
        Me.Button7.Text = "Button7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(126, 25)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(81, 63)
        Me.Button6.TabIndex = 1
        Me.Button6.Text = "Button6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(32, 24)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(80, 64)
        Me.Button5.TabIndex = 0
        Me.Button5.Text = "Button5"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'SubMenu1
        '
        Me.SubMenu1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SubMenu1.Controls.Add(Me.Button4)
        Me.SubMenu1.Controls.Add(Me.Button3)
        Me.SubMenu1.Controls.Add(Me.Button2)
        Me.SubMenu1.Controls.Add(Me.Button1)
        Me.SubMenu1.Location = New System.Drawing.Point(31, 81)
        Me.SubMenu1.Name = "SubMenu1"
        Me.SubMenu1.Size = New System.Drawing.Size(443, 112)
        Me.SubMenu1.TabIndex = 4
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(317, 24)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(86, 64)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Button4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(220, 24)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(86, 64)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(123, 24)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(84, 65)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(32, 24)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(83, 64)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TopMenu
        '
        Me.TopMenu.Location = New System.Drawing.Point(578, 12)
        Me.TopMenu.Name = "TopMenu"
        Me.TopMenu.ScanningInterval = 1000
        Me.TopMenu.Size = New System.Drawing.Size(25, 30)
        Me.TopMenu.TabIndex = 3
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(596, 498)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.SubMenu3)
        Me.Controls.Add(Me.SubMenu2)
        Me.Controls.Add(Me.SubMenu1)
        Me.Controls.Add(Me.TopMenu)
        Me.Name = "MainForm"
        Me.Text = "CPS613 Scanning Example"
        Me.SubMenu3.ResumeLayout(False)
        Me.SubMenu2.ResumeLayout(False)
        Me.SubMenu1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TopMenu As Scanning.TopMenu
    Friend WithEvents SubMenu1 As Scanning.SubMenu
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents SubMenu2 As Scanning.SubMenu
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents SubMenu3 As Scanning.SubMenu
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
